/*
 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 */

var express = require('express'),
	bodyParser = require('body-parser'),
	Usergrid = require('usergrid'),
	cors = require('cors'),
    app = express(),
    jsonParser = bodyParser.json();

app.use(cors());

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Allow-Credentials");
  res.header("Access-Control-Allow-Credentials", "true");
  next();
});

app.set('json spaces', 40);

var UsergridClient = require('./node_modules/usergrid/lib/client')
var Usergrid = new UsergridClient
({
    "appId": "sandbox",
    "orgId": "pocapi-baas",
    "authMode": "NONE",
    "baseUrl": "https://apibaas-trial.apigee.net/",
    "clientId": "b3U6Tf9aFc2vEeahpA7sJBXz3w",
    "clientSecret": "b3U6l0m95GMQ-4abWQAy7_NLul-_rkg"
})

Usergrid.setAppAuth(Usergrid.appAuth.clientId, Usergrid.appAuth.clientSecret);
console.log(Usergrid.appAuth);

Usergrid.authenticateApp(function(err, usergridResponse) 
{
    if (usergridResponse.ok) 
    {
        console.log('app is now authenticated');
    }
})

app.get('/:collection', function(req, res) 
{
	Usergrid.GET(req.params.collection, function(error, usergridResponse) 
	{
	    res.json(usergridResponse.entities);
	    console.log('get /', req.params.collection);
	})
})

app.get('/participants/:participant_id', function(req, res) 
{
	Usergrid.GET('participants', function(error, usergridResponse, entities) 
	{
		for (var i = usergridResponse.entities.length - 1; i >= 0; i--) 
		{
			if (usergridResponse.entities[i].participant_id==req.params.participant_id) 
			{
				res.json(usergridResponse.entities[i]);
				break;
			}
			else if (i==0) 
			{
				res.json({});
			}
		}
	    console.log('get /participants/:participant_id');
	})
})

app.get('/organisateurs/:organisateur_id', function(req, res) 
{
	
	Usergrid.GET('organisateurs', function(error, usergridResponse, entities) 
	{
		for (var i = usergridResponse.entities.length - 1; i >= 0; i--) 
		{
			if (usergridResponse.entities[i].organisateur_id==req.params.organisateur_id) 
			{
				res.json(usergridResponse.entities[i]);
				break;
			}
			else if (i==0) 
			{
				res.json({});
			}
			
		}
	    console.log('get /organisateurs/:organisateur_id');
	})
})

app.get('/organisateurs/:organisateur_id/:evenement_id', function(req, res) 
{
	
	Usergrid.GET('organisateurs', function(error, usergridResponse, entities) 
	{
		for (var i = usergridResponse.entities.length - 1; i >= 0; i--) 
		{
			if (usergridResponse.entities[i].organisateur_id==req.params.organisateur_id) 
			{
				for (var j = usergridResponse.entities[i].evenements.length - 1; j >= 0; j--) 
				{
					if (usergridResponse.entities[i].evenements[j].evenement_id == req.params.evenement_id)
					{
						res.json(usergridResponse.entities[i].evenements[j]);
						break;
					}
					else if (j==0) 
					{
						res.json({});
					}

				}
				break;
			}
			else if (i==0) 
			{
				res.json({});
			}
		}
	    console.log('get organisateurs/organisateur_id/evenement_id');
	})
})

app.get('/organisateurs/:organisateur_id/:evenement_id/:activite_id', function(req, res) 
{
	
	Usergrid.GET('organisateurs', function(error, usergridResponse, entities) 
	{
		for (var i = usergridResponse.entities.length - 1; i >= 0; i--) 
		{
			if (usergridResponse.entities[i].organisateur_id==req.params.organisateur_id) 
			{
				for (var j = usergridResponse.entities[i].evenements.length - 1; j >= 0; j--) 
				{
					if (usergridResponse.entities[i].evenements[j].evenement_id == req.params.evenement_id)
					{
						for (var k = usergridResponse.entities[i].evenements[j].activites.length - 1; k >= 0; k--) 
						{
							if (usergridResponse.entities[i].evenements[j].activites[k].activite_id== req.params.activite_id)
							{
								res.json(usergridResponse.entities[i].evenements[j].activites[k]);
								break;
							}
							else if (k==0) 
							{
								res.json({});
							}

						}
						break;
					}
					else if (j==0) 
					{
						res.json({});
					}
				}
				break;
			}
			else if (i==0) 
			{
				res.json({});
			}
			
		}
	    console.log('get collection organisateurs/organisateur_id/evenement_id/activite_id');
	})
})

app.put('/participants/:participant_id',jsonParser, function(req, res) 
{    
	Usergrid.GET('participants', function(error, usergridResponse, entities) 
	{
		for (var i = usergridResponse.entities.length - 1; i >= 0; i--) 
		{
			if (usergridResponse.entities[i].participant_id==req.params.participant_id) 
			{
				console.log('usergridResponse.entities[i]',usergridResponse.entities[i])
				usergridResponse.entities[i]=req.body;
				console.log('usergridResponse.entities[i]',usergridResponse.entities[i])
				Usergrid.PUT(usergridResponse.entities[i], function(error, usergridResponse, entity) 
				{
			        res.json(usergridResponse.entities[i]);
			    })
				break;
			}
			else if (i==0) 
			{
				res.json({});
			}
		}
	    console.log('put /participants/:participant_id');
	})
})

app.post('/organisateurs',jsonParser, function(req, res) 
{    
	Usergrid.POST('organisateurs',req.body, function(error, usergridResponse, entity) 
	{
	    res.json(req.body);
	    console.log('post /organisateurs');
	})
})

app.post('/participants',jsonParser, function(req, res) 
{    
	Usergrid.POST('participants',req.body, function(error, usergridResponse, entity) 
	{
	    res.json(req.body);
	    console.log('post /participants');
	})
})

app.post('/participants/:participant_id/inscription',jsonParser, function(req, res) 
{    
	Usergrid.GET('participants', function(error, usergridResponse, entities) 
	{
		for (var i = usergridResponse.entities.length - 1; i >= 0; i--) 
		{
			if (usergridResponse.entities[i].participant_id==req.params.participant_id) 
			{
				usergridResponse.entities[i].inscription.push(req.body)
				Usergrid.PUT(usergridResponse.entities[i], function(error, usergridResponse, entity) 
				{
			        res.json(usergridResponse.entities[i]);
			    })
				break;
			}
			else if (i==0) 
			{
				res.json({});
			}
		}
	    console.log('post /participants/:participant_id/inscription');
	})
})


app.post('/organisateurs/:organisateur_id/:evenement_id/:activite_id/inscription',jsonParser, function(req, res) 
{
	Usergrid.GET('organisateurs', function(error, usergridResponse, entities) 
	{
		for (var i = usergridResponse.entities.length - 1; i >= 0; i--) 
		{
			if (usergridResponse.entities[i].organisateur_id==req.params.organisateur_id) 
			{
				for (var j = usergridResponse.entities[i].evenements.length - 1; j >= 0; j--) 
				{
					if (usergridResponse.entities[i].evenements[j].evenement_id == req.params.evenement_id)
					{
						for (var k = usergridResponse.entities[i].evenements[j].activites.length - 1; k >= 0; k--) 
						{
							if (usergridResponse.entities[i].evenements[j].activites[k].activite_id== req.params.activite_id)
							{
								usergridResponse.entities[i].evenements[j].activites[k].inscris.push(req.body)
								Usergrid.PUT(usergridResponse.entities[i], function(error, usergridResponse, entity) 
								{
							        res.json(usergridResponse.entities[i]);
							    })
								break;
							}
							else if (k==0) 
							{
								res.json({});
							}

						}
						break;
					}
					else if (j==0) 
					{
						res.json({});
					}
				}
				break;
			}
			else if (i==0) 
			{
				res.json({});
			}
			
		}
		console.log('post /organisateurs/:organisateur_id/:evenement_id/:activite_id/inscription')
	})
})

app.delete('/organisateurs/:organisateur_id', function(req, res) 
{
	Usergrid.GET('organisateurs', function(error, usergridResponse, entities) 
	{
		for (var i = usergridResponse.entities.length - 1; i >= 0; i--) 
		{
			if (usergridResponse.entities[i].organisateur_id==req.params.organisateur_id) 
			{
			    data_delete=usergridResponse.entities[i];
				Usergrid.DELETE('organisateurs',usergridResponse.entities[i].uuid, function(error, usergridResponse, entities) 
				{
                    res.json(data_delete);
				})
				break;
			}
			else if (i==0) 
			{
				res.json({});
			}
			
		}
	    console.log('delete organisateurs/organisateur_id');
	})
})

app.delete('/organisateurs/:organisateur_id/:evenement_id/:activite_id/inscription/:id_participant',jsonParser, function(req, res) 
{
	Usergrid.GET('organisateurs', function(error, usergridResponse, entities) 
	{
		for (var i = usergridResponse.entities.length - 1; i >= 0; i--) 
		{
			if (usergridResponse.entities[i].organisateur_id==req.params.organisateur_id) 
			{
				for (var j = usergridResponse.entities[i].evenements.length - 1; j >= 0; j--) 
				{
					if (usergridResponse.entities[i].evenements[j].evenement_id == req.params.evenement_id)
					{
						for (var k = usergridResponse.entities[i].evenements[j].activites.length - 1; k >= 0; k--) 
						{
							if (usergridResponse.entities[i].evenements[j].activites[k].activite_id== req.params.activite_id)
							{
								for (var l = usergridResponse.entities[i].evenements[j].activites[k].inscris.length - 1; l >= 0; l--) 
								{
									if (usergridResponse.entities[i].evenements[j].activites[k].inscris[l].id_participant== req.params.id_participant)
									{
										data_delete=usergridResponse.entities[i].evenements[j].activites[k].inscris.splice(l, 1);
										Usergrid.PUT(usergridResponse.entities[i], function(error, usergridResponse, entity) 
										{
									        res.json(data_delete);
									    })
										break;
									}
									else if (l==0) 
									{
										res.json({});
									}

								}
								break;
							}
							else if (k==0) 
							{
								res.json({});
							}

						}
						break;
					}
					else if (j==0) 
					{
						res.json({});
					}
				}
				break;
			}
			else if (i==0) 
			{
				res.json({});
			}
			
		}
		console.log('delete /organisateurs/:organisateur_id/:evenement_id/:activite_id/inscription/:id_participant');
	})
})

app.delete('/participants/:participant_id/inscription',jsonParser, function(req, res) 
{
	Usergrid.GET('participants', function(error, usergridResponse, entities) 
	{
		for (var i = usergridResponse.entities.length - 1; i >= 0; i--) 
		{
			if (usergridResponse.entities[i].participant_id==req.params.participant_id) 
			{
				for (var j = usergridResponse.entities[i].inscription.length - 1; j >= 0; j--) 
				{
					if (usergridResponse.entities[i].inscription[j].id_activite== req.query.id_activite
						&& usergridResponse.entities[i].inscription[j].id_evenement== req.query.id_evenement) 
					{
						data_delete=usergridResponse.entities[i].inscription.splice(j,1);
						Usergrid.PUT(usergridResponse.entities[i], function(error, usergridResponse, entity) 
						{
					        res.json(data_delete);
					    })
						break;
					}
					else if (j==0) 
					{
						res.json({});
					}
				}		
				break;
			}
			else if (i==0) 
			{
				res.json({});
			}
		}
	    console.log('delete /participants/:participant_id/inscription');
	})
})

app.listen(process.env.port || 9000)